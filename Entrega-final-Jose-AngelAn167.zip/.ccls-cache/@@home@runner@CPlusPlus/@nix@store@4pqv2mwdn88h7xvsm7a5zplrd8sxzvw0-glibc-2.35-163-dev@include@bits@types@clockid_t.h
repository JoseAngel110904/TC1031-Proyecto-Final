#ifndef __clockid_t_defined
#define __clockid_t_defined 1

#include <bits/types.h>

/* Clock ID used in clock and timer functions.  */
typedef __clockid_t clockid_t;

#endif
