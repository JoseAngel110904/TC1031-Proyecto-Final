#include <iostream>
#include <fstream>
#include <string>
using namespace std;

class NodoPasajeros{
private:
  string Name;
  string Dest;
  int Edad;
  int Npasajeros;

public:
NodoPasajeros * siguiente;
NodoPasajeros(string _name, string _Destino, int _Edad, int _Npasajeros){
  Name = _name;
  Dest = _Destino;
  Edad = _Edad;
  Npasajeros = _Npasajeros;
}

string getname(){
  return Name;
}

string getdest(){
  return Dest;
}

int getedad(){
  return Edad;
}

int getNpasajeros(){
  return Npasajeros;
}

void disp(){
  cout<<" "<<endl;
  cout<<"Representante de la familia/Grupo : "<<Name<<endl;
  cout<<"Destino: "<<Dest<<endl;
  cout<<"Edad: "<<Dest<<endl;
  cout<<"N.pasajeros : "<<Npasajeros<<endl;
  }
};

class Linkedlist{
private:
  NodoPasajeros*head;
  NodoPasajeros*tail;
  NodoPasajeros*current;

public:
  Linkedlist(): head(nullptr),tail(nullptr),current(nullptr) {};

  void RegistroPasajero(string _NAME, string _DEST,int _Edad,int _NPasajeros){
    NodoPasajeros * NewPasajero = new NodoPasajeros(_NAME, _DEST, _Edad, _NPasajeros);
    if(tail == nullptr){
      head = NewPasajero;
      tail = NewPasajero;
      current = NewPasajero;
    }else {
      tail -> siguiente = NewPasajero;
      tail = NewPasajero; 
    }
  };
  
  void BuscaPasajero(string _NAME){
    bool find = false;
    while(current!=nullptr && find !=true){
      if(current->getname()==_NAME){
        current->disp();
        find = true;
        }else{
        current = current->siguiente;
        }
      }
    if(find != true){
      cout<<"| No se encontro pasajero "<<_NAME<<"|"<<endl;
      current = head;
    }else current = head;
    };
  
  void BorrarPasajero(string _NAME){
    NodoPasajeros* victima;
    bool find = false;
    while(current!=nullptr && find !=true){
      if(current->siguiente->getname()==_NAME){
        victima = current -> siguiente;
        find = true;
        }else{
        current = current->siguiente;
        }
      }
    if(find != true){
      
      cout<<"| No se encontro pasajero "<<_NAME<<"|"<<endl;
      current = head;
    }else{
      current->siguiente = victima -> siguiente;
      victima = nullptr;
      current = head;
      
    }
  }

  void database(){
    string nombre, planetaDestino;
    int edad, numPasajeros;

    // Abrir un archivo de texto para escribir (se creará si no existe)
    ofstream archivo("registro_pasajeros.txt", ios::app); // ios::app para añadir datos al archivo si ya existe
    if (archivo.is_open()) {
      while(current!=tail){
        nombre = current->getname();
        planetaDestino = current->getdest();
        edad = current ->getedad();
        numPasajeros = current->getNpasajeros();
        // Escribir los datos del pasajero en el archivo
        archivo << "Nombre: " << nombre << endl;
        archivo << "Planeta destino: " << planetaDestino << endl;
        archivo << "Edad: " << edad << endl;
        archivo << "Número de pasajeros: " << numPasajeros << endl;
        archivo << "------------------------" << endl;
        archivo << " " << endl;

        current = current->siguiente;
      }
        // Cerrar el archivo
        archivo.close();
        cout << "Se guardo el archivo correctamente." << endl;
    } else {
        cout << "No se pudo abrir el archivo para escribir." << endl;
    }
  }

void MostrarRegistroPasajeros() {
    ifstream archivo("registro_pasajeros.txt");

    if (archivo.is_open()) {
        string linea;
        bool archivoVacio = true; // Variable para verificar si el archivo está vacío

        while (getline(archivo, linea)) {
            cout << linea << endl;
            archivoVacio = false; // Se encontró al menos una línea en el archivo
        }

        archivo.close();

        if (archivoVacio) {
            cout << "No hay registro de pasajeros." << endl;
        }
    } else {
        cout << "No se pudo abrir el registro." << endl;
    }
}

};