#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <algorithm>

using namespace std;

class NodoPasajeros{
private:
  string Name;
  string Dest;
  int Npasajeros;

public:
NodoPasajeros * anterior;
NodoPasajeros * siguiente;
NodoPasajeros(string _name, string _Destino, int _Npasajeros){
  Name = _name;
  Dest = _Destino;
  Npasajeros = _Npasajeros;
}

};

void RegistrarPasajero() {
    // Solicitar información del pasajero
    string nombre, planetaDestino;
    int edad, numPasajeros;

    cout << "Nombre del pasajero: ";
    cin >> nombre;
    cout << "Planeta destino: ";
    cin >> planetaDestino;
    cout << "Edad: ";
    cin >> edad;
    cout << "Número de pasajeros: ";
    cin >> numPasajeros;

    // Abrir un archivo de texto para escribir (se creará si no existe)
    ofstream archivo("registro_pasajeros.txt", ios::app); // ios::app para añadir datos al archivo si ya existe

    if (archivo.is_open()) {
        // Escribir los datos del pasajero en el archivo
        archivo << "Nombre: " << nombre << endl;
        archivo << "Planeta destino: " << planetaDestino << endl;
        archivo << "Edad: " << edad << endl;
        archivo << "Número de pasajeros: " << numPasajeros << endl;
        archivo << "------------------------" << endl;
        archivo << " " << endl;

        // Cerrar el archivo
        archivo.close();
        cout << "Los datos del pasajero se han registrado en el archivo." << endl;
    } else {
        cout << "No se pudo abrir el archivo para escribir." << endl;
    }
}

void MostrarRegistroPasajeros() {
    ifstream archivo("registro_pasajeros.txt");

    if (archivo.is_open()) {
        string linea;
        bool archivoVacio = true; // Variable para verificar si el archivo está vacío

        while (getline(archivo, linea)) {
            cout << linea << endl;
            archivoVacio = false; // Se encontró al menos una línea en el archivo
        }

        archivo.close();

        if (archivoVacio) {
            cout << "No hay registro de pasajeros." << endl;
        }
    } else {
        cout << "No se pudo abrir el registro." << endl;
    }
}

void EliminarPasajeroPorNombre() {
    string victima;
    cout << "Ingrese el nombre del pasajero a eliminar: ";
    cin.ignore();
    getline(cin, victima);

    ifstream archivoEntrada("registro_pasajeros.txt");
    ofstream archivoSalida("temp.txt");
    vector<string> datosPasajero;
    string linea;

    if (!archivoEntrada.is_open() || !archivoSalida.is_open()) {
        cout << "Error al abrir los archivos." << endl;
        return;
    }

    bool Busqueda = false; // Bool para saber si la busqueda del nombre tuvo exito

    while (getline(archivoEntrada, linea)) {
        if (linea.find("Nombre: " + victima) != string::npos) {
            // Marcar el pasajero como encontrado
            Busqueda = true;
            // Leer y descartar todas las líneas relacionadas con el pasajero
            for (int i = 0; i < 5; i++) {
                getline(archivoEntrada, linea);
            }
        } else {
            // Guardar las líneas que no pertenecen al pasajero en el archivo de salida
            archivoSalida << linea << endl;
        }
    }

    archivoEntrada.close();
    archivoSalida.close();

    if (Busqueda) {
        remove("registro_pasajeros.txt");
        rename("temp.txt", "registro_pasajeros.txt");
        cout << "Los datos del pasajero han sido eliminados." << endl;
    } else {
        remove("temp.txt");
        cout << "No se encontraron datos para el pasajero especificado." << endl;
    }
}
